# 🚀 Déploiement Rapide MangaView

## 1. Upload sur Hostinger
Uploadez TOUS les fichiers de ce dossier vers `public_html/` sur votre hébergement Hostinger.

## 2. Structure finale
```
public_html/
├── .next/          ← Dossier de build Next.js
├── public/         ← Assets statiques
├── package.json    ← Dépendances
├── next.config.ts  ← Configuration Next.js
├── .htaccess      ← Configuration Apache
└── server.js      ← Serveur Node.js
```

## 3. Installation des dépendances
```bash
cd public_html
npm install --production
```

## 4. Démarrage du serveur
```bash
npm start
```

## 5. Configuration du domaine
- Pointez votre domaine vers ce dossier
- Activez HTTPS si disponible
- Vérifiez que le port 3000 est ouvert

## 🎯 Votre site sera accessible sur : https://votre-domaine.com
