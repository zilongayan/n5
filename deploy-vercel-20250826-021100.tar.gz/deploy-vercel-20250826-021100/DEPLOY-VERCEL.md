# 🚀 Déploiement Vercel MangaView

## 1. Installation de Vercel CLI
```bash
npm install -g vercel
```

## 2. Connexion à Vercel
```bash
vercel login
```

## 3. Déploiement
```bash
vercel --prod
```

## 4. Variables d'environnement
Configurez vos variables d'environnement dans le dashboard Vercel :
- DATABASE_URL
- NEXTAUTH_SECRET
- NEXTAUTH_URL

## 5. Domaine personnalisé
Dans le dashboard Vercel, ajoutez votre domaine personnalisé.

## 🎯 Votre site sera accessible sur : https://votre-projet.vercel.app
